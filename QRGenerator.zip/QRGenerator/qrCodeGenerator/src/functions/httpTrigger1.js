const { app } = require('@azure/functions');
const QRCode = require('qrcode');
const {
    BlobServiceClient,
    StorageSharedKeyCredential,
    BlobSASPermissions,
    generateBlobSASQueryParameters
} = require('@azure/storage-blob');

// Your Azure Storage Account credentials
const accountName = "newrga27f";
const accountKey = "Igkfm1AgLyvv0xPSQI+Jy8P3HRoTPk0E05vQ4y5UIz6dxBupp+3VD1yv/MrZZK6ov4YkKim9Ouid+AStVhKrjA==";
const connectionString = `DefaultEndpointsProtocol=https;AccountName=${accountName};AccountKey=${accountKey};EndpointSuffix=core.windows.net`;

app.http('httpTrigger1', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log('Starting QR Code generation...');

        // Step 1: Extract URL
        let url = request.query.get('url');
        if (!url) {
            try {
                const body = await request.json();
                url = body?.url;
            } catch {
                context.log('⚠️ Could not parse body JSON.');
            }
        }

        if (!url) {
            return {
                status: 400,
                body: "Please pass a URL in the query string or in the request body"
            };
        }

        context.log(`URL received: ${url}`);

        try {
            // Step 2: Generate QR Code
            const qrCodeData = await QRCode.toDataURL(url);
            context.log('QR Code generated successfully.');

            // Step 3: Initialize Azure Blob Service
            const blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);
            const containerName = 'input-files';
            const containerClient = blobServiceClient.getContainerClient(containerName);
            await containerClient.createIfNotExists(); // no public access parameter
            context.log('Blob container ready.');

            // Step 4: Prepare blob name
            const modifiedUrl = url.replace(/^https?:\/\//, '');
            const blobName = modifiedUrl.replace(/[^\w.-]/g, '_') + '.png';
            const blockBlobClient = containerClient.getBlockBlobClient(blobName);

            // Step 5: Convert QR Data to Buffer
            const matches = qrCodeData.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
            if (!matches || matches.length !== 3) {
                throw new Error('Invalid QR Code data format');
            }
            const buffer = Buffer.from(matches[2], 'base64');

            // Step 6: Upload (overwrite if exists)
            await blockBlobClient.upload(buffer, buffer.length, { overwrite: true });
            context.log(`Uploaded QR Code as blob: ${blobName}`);

            // Step 7: Generate SAS Token for secure access
            const sharedKeyCredential = new StorageSharedKeyCredential(accountName, accountKey);
            const sasToken = generateBlobSASQueryParameters({
                containerName: containerName,
                blobName: blobName,
                permissions: BlobSASPermissions.parse("r"), // read-only
                expiresOn: new Date(new Date().valueOf() + 3600 * 1000) // valid for 1 hour
            }, sharedKeyCredential).toString();

            const sasUrl = `${blockBlobClient.url}?${sasToken}`;
            context.log(`Generated secure SAS URL: ${sasUrl}`);

            // Step 8: Return SAS URL
            return {
                status: 200,
                jsonBody: { qr_code_url: sasUrl },
                headers: { 'Content-Type': 'application/json' }
            };

        } catch (error) {
            context.log(`Error: ${error.message}`);
            return {
                status: 500,
                body: `Error generating QR Code or uploading to Azure Blob Storage: ${error.message}`
            };
        }
    }
});
